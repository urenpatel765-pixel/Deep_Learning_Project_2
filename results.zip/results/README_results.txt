# Results folder

This folder contains tabular experiment results extracted from the saved outputs
of `Deep_Learning_Project_2.ipynb`.

- The CSV files preserve tables that were displayed in the executed notebook.
- They are provided as supporting result summaries for the practical submission.
- They are not a reconstruction of every intermediate CSV export originally
  written by the notebook during its execution.
- To regenerate the notebook's complete original exports, rerun the notebook
  from top to bottom in an environment with the dataset and required packages.

Evaluation note: some experiments report validation metrics while the final
model reports test metrics. These evaluation splits are identified in the
relevant CSV filenames or columns and should not be treated as interchangeable.
